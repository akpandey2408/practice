package com.exampleCrud.Adamya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdamyaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdamyaApplication.class, args);
	}

}
